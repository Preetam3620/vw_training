package com.example.project.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.project.entity.Book;

import jakarta.transaction.Transactional;

public interface BookRepository extends JpaRepository<Book, Long> {
	Optional<Book> findByBookId(int bookId);
	Optional<Book> findByBookName(String bookName);
	Optional<Boolean> removeByBookId(int bookId);
}
